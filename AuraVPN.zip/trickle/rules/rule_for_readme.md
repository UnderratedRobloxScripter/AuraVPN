When updating the project
- Always check if the README.md needs to be updated to reflect new features, file structures, or instructions.
- Keep the README.md concise and up-to-date.